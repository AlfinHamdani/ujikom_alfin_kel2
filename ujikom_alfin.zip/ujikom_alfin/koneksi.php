<?php
$koneksi = mysqli_connect("localhost", "root", "", "appem_alfin_kel2");


?>